import os
import discord
from discord.ext import commands

TOKEN = os.getenv("TOKEN") or "COLOQUE_SEU_TOKEN_AQUI"

intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(command_prefix=".", intents=intents)

estoque = {
    "netflix": [
        "CODIGO-01",
        "CODIGO-02",
        "CODIGO-03"
    ]
}

@bot.event
async def on_ready():
    print(f"Bot online: {bot.user}")

@bot.command()
async def estoque(ctx):
    texto = ""
    for nome, itens in estoque.items():
        texto += f"{nome}: {len(itens)} disponível(is)\n"

    embed = discord.Embed(
        title="📦 ESTOQUE",
        description=texto,
        color=0xff0000
    )
    await ctx.send(embed=embed)

@bot.command()
async def gen(ctx, produto=None):
    if produto is None:
        await ctx.send("Use: .gen netflix")
        return

    produto = produto.lower()

    if produto not in estoque:
        await ctx.send("Produto não encontrado.")
        return

    if len(estoque[produto]) <= 0:
        await ctx.send("Sem estoque.")
        return

    item = estoque[produto].pop(0)

    try:
        await ctx.author.send(f"✅ Seu item:\n{item}")
        await ctx.send("✅ Confira sua DM.")
    except Exception:
        await ctx.send("❌ Não consegui enviar DM. Abra seu privado.")

bot.run(TOKEN)
